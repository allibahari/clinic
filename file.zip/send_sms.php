<?php
require 'vendor/autoload.php';

use Melipayamak\MelipayamakApi;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // دریافت پارامترها از درخواست
    $employee_id = $_POST['id'];
    $message = $_POST['message'];

    // اطلاعات اتصال به پایگاه داده
    include "config.php";

    // دریافت شماره موبایل کاربر از پایگاه داده
    $sql = "SELECT mobile FROM employees1 WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $employee_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $mobile = $row['mobile'];

        // ارسال پیامک
        $username = '989015255027';
        $password = 'f8e6b48f-8e46-4b4a-8cd6-304392c48fea';

        try {
            $api = new MelipayamakApi($username, $password);
            $sms = $api->sms();
            $from = '50002710055027'; // شماره ارسال کننده
            $isFlash = false;

            // ارسال پیامک
            $response = $sms->send($mobile, $from, $message, $isFlash);

            // بررسی وضعیت ارسال پیامک
            if ($response) {
                echo 'پیامک با موفقیت ارسال شد!';
            } else {
                echo 'خطا در ارسال پیامک.';
            }
        } catch (Exception $e) {
            echo 'خطا در ارسال پیامک: ' . $e->getMessage();
        }
    } else {
        echo 'کاربر یافت نشد.';
    }
    $stmt->close();
    $conn->close();
} else {
    echo 'درخواست نامعتبر است.';
}
?>
