<?php
session_start(); // شروع سشن
?>
